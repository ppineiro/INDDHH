_________________            __________________________
___    |__  /__(_)__   _________  __ \__  __ \__  ____/
__  /| |_  /__  /__ | / /  _ \_  /_/ /_  / / /_  /_    
_  ___ |  / _  / __ |/ //  __/  ____/_  /_/ /_  __/
/_/  |_/_/  /_/  _____/ \___//_/     /_____/ /_/  
     
Copyright (c) 2008 Thibault Imbert

The AlivePDF.swc is for Flex Builder 3 Beta
If you are running with Flex Builder 2 or Flash, use the source classes.

Release 0.1.4.9

alivepdf.bytearray.org